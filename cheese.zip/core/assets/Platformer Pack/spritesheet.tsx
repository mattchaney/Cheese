<?xml version="1.0" encoding="UTF-8"?>
<tileset name="tiles_spritesheet" tilewidth="70" tileheight="70" spacing="1">
 <image source="../../../cheese-game/assets/data/Platformer Pack/tiles_spritesheet.png" width="852" height="856"/>
</tileset>
